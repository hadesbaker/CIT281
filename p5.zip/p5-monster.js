module.exports = class Monster {
    constructor({ monsterName = "Unknown", minimumLife = minimumLife, currentLife = currentLife}) {
        this.monsterName = monsterName;
        this.minimumLife = minimumLife;
        this.currentLife = currentLife;
        this.isAlive = currentLife >= minimumLife;
    }

    updateLife() = (lifeChangeAmount) => {
        this.currentLife += lifeChangeAmount;
        this.currentLife += this.currentLife < 0 ? 0: this.currentLife;
        this.isAlive = this.currentLife < this.minimumLife;
    };

    randomLifeDrain(minimumLifeDrain, maximumLifeDrain) {
        const randomLifeChange = getRandomInteger(minimumLifeDrain, maximumLifeDrain + 1);
        this.updateLife(-randomLifeChange);
      }
}

export default Monster;
