/*
    CIT 281 Project 1
    Name: Taki Alyasri
*/

function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

function randomString(length) {
    let answer = ' ';
    const letter_Pool = 'abcdefghijklmnopqrstuvwxyz';
    const letterPoollength = length;
    for ( let i = 0; i < length; i++ ) {
        answer += letter_Pool.charAt(Math.floor(Math.random() * letterPoollength));
    }
    return answer;
}

console.log(randomString(getRandomInteger(5, 26)))