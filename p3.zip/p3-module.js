// #1
function validDenomination(coin) {
    const denominations = [1, 5, 10, 25, 50, 100];
    return denominations.indexOf(coin) !== -1;
  }
//console.log(validDenomination(1));   

// #2
function valueFromCoinObject(obj) {
    const { denom = 0, count = 0 } = obj;
    const validDenominations = [1, 5, 10, 25, 50, 100];
    
    if (!validDenominations.includes(denom)) {
      throw new Error('Invalid denomination');
    }
    
    if (!Number.isInteger(count) || count < 0) {
      throw new Error('Invalid count');
    }
    
    return denom * count;
  }
//console.log(valueFromCoinObject({ denom: 50, count: 1 }));

// #3
function valueFromArray(arr) {
    return arr.reduce((total, coin) => total + valueFromCoinObject(coin), 0);
  }  
const myArray = [
    { denom: 50, count: 2 },
    { denom: 25, count: 4 },
    { denom: 5, count: 20 },
    { denom: 1, count: 50 }
];
//console.log(valueFromArray(coinage));

// #4
function coinCount(...coinage) {
  return valueFromArray(coinage);
}
//console.log(coinCount(...myArray)); // Output: 67

console.log("{}", coinCount({denom: 5, count: 3})); 
console.log("{}s", coinCount({denom: 5, count: 3},{denom: 10, count: 2})); 
const coins = [{denom: 25, count: 2},{denom: 1, count: 7}]; 
console.log("...[{}]", coinCount(...coins)); 
