const { data } = require("./p4-data");

function getQuestions() {
  const questions = data.map((prop) => prop.question);
  return questions;
}
//console.log(getQuestions());

function getAnswers() {
  const answers = data.map((prop) => prop.answer);
  return answers;
}
//console.log(getAnswers());

function getQuestionsAnswers() {
  return [...data];
}
//console.log(getQuestionsAnswers());

function getQuestion(number = "") {
  const num = parseInt(number);
  if (isNaN(num) || num < 1 || num > data.length) {
    return {
      question: "",
      number: "",
      error: "Invalid Option",
    };
  }
  const questionObj = data[num - 1];
  return {
    question: questionObj.question,
    number: num,
    error: "",
  };
}
//console.log(getQuestion((number = "4")));

function getAnswer(number = "") {
  const num = parseInt(number);
  if (isNaN(num) || num < 1 || num > data.length) {
    return {
      answer: "",
      number: "",
      error: "Invalid Option",
    };
  }
  const answerObj = data[num - 1];
  return {
    answer: answerObj.answer,
    number: num,
    error: "",
  };
}
//console.log(getAnswer((number = "4")));

function getQuestionAnswer(number = "") {
  const num = parseInt(number);
  if (isNaN(num) || num < 1 || num > data.length) {
    return {
      question: "",
      answer: "",
      number: "",
      error: "Invalid Option",
    };
  }
  const questionAnswerObj = data[num - 1];
  return {
    question: questionAnswerObj.question,
    answer: questionAnswerObj.answer,
    number: num,
    error: "",
  };
}
//console.log(getQuestionAnswer((number = "4")));

/*****************************
  Module function testing
******************************/
function testing(category, ...args) {
  console.log(`\n** Testing ${category} **`);
  console.log("-------------------------------");
  for (const o of args) {
    console.log(`-> ${category}${o.d}:`);
    console.log(o.f);
  }
}
// Set a constant to true to test the appropriate function
const testGetQs = false;
const testGetAs = false;
const testGetQsAs = false;
const testGetQ = false;
const testGetA = false;
const testGetQA = false;
const testAdd = false; // Extra credit
const testUpdate = false; // Extra credit
const testDelete = false; // Extra credit

// getQuestions()
if (testGetQs) {
  testing("getQuestions", { d: "()", f: getQuestions() });
}

// getAnswers()
if (testGetAs) {
  testing("getAnswers", { d: "()", f: getAnswers() });
}

// getQuestionsAnswers()
if (testGetQsAs) {
  testing("getQuestionsAnswers", { d: "()", f: getQuestionsAnswers() });
}

// getQuestion()
if (testGetQ) {
  testing(
    "getQuestion",
    { d: "()", f: getQuestion() }, // Extra credit: +1
    { d: "(0)", f: getQuestion(0) }, // Extra credit: +1
    { d: "(1)", f: getQuestion(1) },
    { d: "(4)", f: getQuestion(4) } // Extra credit: +1
  );
}

// getAnswer()
if (testGetA) {
  testing(
    "getAnswer",
    { d: "()", f: getAnswer() }, // Extra credit: +1
    { d: "(0)", f: getAnswer(0) }, // Extra credit: +1
    { d: "(1)", f: getAnswer(1) },
    { d: "(4)", f: getAnswer(4) } // Extra credit: +1
  );
}

// getQuestionAnswer()
if (testGetQA) {
  testing(
    "getQuestionAnswer",
    { d: "()", f: getQuestionAnswer() }, // Extra credit: +1
    { d: "(0)", f: getQuestionAnswer(0) }, // Extra credit: +1
    { d: "(1)", f: getQuestionAnswer(1) },
    { d: "(4)", f: getQuestionAnswer(4) } // Extra credit: +1
  );
}

module.exports = {
  getQuestions,
  getAnswers,
  getQuestionsAnswers,
  getQuestion,
  getAnswer,
  getQuestionAnswer,
};
