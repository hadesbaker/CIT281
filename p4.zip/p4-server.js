const { getQuestions,
    getAnswers,
    getQuestionsAnswers,
    getQuestion,
    getAnswer,
    getQuestionAnswer } = require("./p4-module");
const { data } = require("./p4-data");


const fastify = require("fastify")();

fastify.get("/cit/question", (request, reply) => {
    const message = {
        error: '',
        statusCode: 200,
        questions: getQuestions(),
    }
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(message);
});

fastify.get("/cit/answer", (request, reply) => {
    const message = {
        error: '',
        statusCode: 200,
        answers: getAnswers(),
    }
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(message);

});

fastify.get("/cit/questionanswer", (request, reply) => {
    const message = {
        error: '',
        statusCode: 200,
        questions_answers: getQuestionsAnswers(),
    }
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(message);

});

fastify.get("/cit/question/:number", (request, reply) => {
    const { number } = request.params;
    const id = request.params;
    const questionObj = data[parseInt(number) - 1];
    const message = {
        error: '',
        statusCode: 200,
        question: questionObj.question,
        number: number,
    }
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(message);
});

fastify.get("/cit/answer/:number", (request, reply) => {
    const { number } = request.params;
    const id = request.params;
    const questionObj = data[parseInt(number) - 1];
    const message = {
        error: '',
        statusCode: 200,
        answer: questionObj.answer,
        number: number,
    }
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(message);
});

fastify.get("/cit/questionanswer/:number", (request, reply) => {
    const { number } = request.params;
    const id = request.params;
    const questionObj = data[parseInt(number) - 1];
    const message = {
        error: '',
        statusCode: 200,
        question: questionObj.question,
        answer: questionObj.answer,
        number: number,
    }
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(message);
});

fastify.get("*", (request, reply) => {
    message = {
        error: "Route not found",
        statusCode: 404,
    }
    reply
        .code(404)
        .header("Content-Type", "text/text; charset=utf-8")
        .send(message);
});

const listenIP = "localhost";
const listenPort = 8888;

fastify.listen(listenPort, listenIP, (err, address) => {
  if (err) {
    console.log(err);
    process.exit(1);
  }
  console.log(`Server listening on ${address}`);
});
