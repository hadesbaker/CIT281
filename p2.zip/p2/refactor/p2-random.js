/*
    CIT 281 Project 2
    Name: Taki Alyasri
*/

// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
let result = "";
for (let i = 0; i < getRandomInteger(5, 26); i++) {
    result += alphabet[getRandomInteger(1,alphabet.length-1)];
}
//console.log(result);

function getRandomLetter() {
    // Returns a random letter from the alphabet constant
    return alphabet[Math.floor(Math.random() * alphabet.length)];
}

for (let i = 0; i < getRandomLetter(); i++) {
    result += alphabet[getRandomLetter()];
}

//console.log(getRandomLetter());
//console.log(result);

function getRandomString(minLength, maxLength) {
    // Returns a random string generated from the from the getRandomLetter function
    const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
    for (let i = 0; i <length; i++) {
        result += getRandomLetter();
    }
    return result;
}

//console.log(getRandomString(10, 20));

function getSortedString(string) {
    // Returns the contents of string sorted in alphabetical order
    return string.split('').sort().join('');
}

console.log(getSortedString('ksjduahdusodk'));